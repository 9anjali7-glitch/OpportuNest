import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Opportunity, Course, LearningProgress, Streak, Notification } from '../lib/types';
import { mockOpportunities, mockCourses } from '../lib/mockData';

interface AppContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  opportunities: Opportunity[];
  courses: Course[];
  savedOpportunities: string[];
  toggleSaveOpportunity: (id: string) => void;
  learningProgress: LearningProgress[];
  updateLearningProgress: (courseId: string, progress: number) => void;
  enrollInCourse: (courseId: string) => void;
  streak: Streak;
  updateStreak: () => void;
  notifications: Notification[];
  markNotificationAsRead: (id: string) => void;
  addNotification: (notification: Omit<Notification, 'id'>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUserState] = useState<User | null>(null);
  const [savedOpportunities, setSavedOpportunities] = useState<string[]>([]);
  const [learningProgress, setLearningProgress] = useState<LearningProgress[]>([]);
  const [streak, setStreak] = useState<Streak>({
    currentStreak: 0,
    longestStreak: 0,
    lastStudyDate: ''
  });
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Load data from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('opportunest_user');
    const storedSaved = localStorage.getItem('opportunest_saved');
    const storedProgress = localStorage.getItem('opportunest_progress');
    const storedStreak = localStorage.getItem('opportunest_streak');
    const storedNotifications = localStorage.getItem('opportunest_notifications');

    if (storedUser) setUserState(JSON.parse(storedUser));
    if (storedSaved) setSavedOpportunities(JSON.parse(storedSaved));
    if (storedProgress) setLearningProgress(JSON.parse(storedProgress));
    if (storedStreak) setStreak(JSON.parse(storedStreak));
    if (storedNotifications) setNotifications(JSON.parse(storedNotifications));
  }, []);

  const setUser = (user: User | null) => {
    setUserState(user);
    if (user) {
      localStorage.setItem('opportunest_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('opportunest_user');
    }
  };

  const toggleSaveOpportunity = (id: string) => {
    setSavedOpportunities(prev => {
      const newSaved = prev.includes(id)
        ? prev.filter(oppId => oppId !== id)
        : [...prev, id];
      localStorage.setItem('opportunest_saved', JSON.stringify(newSaved));
      return newSaved;
    });
  };

  const updateLearningProgress = (courseId: string, progress: number) => {
    const today = new Date().toISOString().split('T')[0];
    setLearningProgress(prev => {
      const existing = prev.find(p => p.courseId === courseId);
      let newProgress;
      
      if (existing) {
        newProgress = prev.map(p =>
          p.courseId === courseId
            ? { ...p, progress, lastStudied: today, completed: progress >= 100 }
            : p
        );
      } else {
        newProgress = [...prev, {
          courseId,
          progress,
          lastStudied: today,
          completed: progress >= 100
        }];
      }
      
      localStorage.setItem('opportunest_progress', JSON.stringify(newProgress));
      return newProgress;
    });

    // Update streak when progress is made
    updateStreak();
  };

  const enrollInCourse = (courseId: string) => {
    updateLearningProgress(courseId, 0);
    addNotification({
      type: 'learning',
      title: 'Course Enrolled',
      message: 'You have successfully enrolled in a new course!',
      date: new Date().toISOString(),
      read: false
    });
  };

  const updateStreak = () => {
    const today = new Date().toISOString().split('T')[0];
    
    setStreak(prev => {
      let newStreak = { ...prev };
      
      if (prev.lastStudyDate === today) {
        // Already studied today
        return prev;
      }
      
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];
      
      if (prev.lastStudyDate === yesterdayStr || prev.lastStudyDate === '') {
        // Continue streak
        newStreak.currentStreak = prev.currentStreak + 1;
        newStreak.longestStreak = Math.max(newStreak.currentStreak, prev.longestStreak);
      } else {
        // Streak broken
        newStreak.currentStreak = 1;
      }
      
      newStreak.lastStudyDate = today;
      localStorage.setItem('opportunest_streak', JSON.stringify(newStreak));
      
      return newStreak;
    });
  };

  const addNotification = (notification: Omit<Notification, 'id'>) => {
    setNotifications(prev => {
      const newNotification: Notification = {
        ...notification,
        id: Date.now().toString()
      };
      const newNotifications = [newNotification, ...prev];
      localStorage.setItem('opportunest_notifications', JSON.stringify(newNotifications));
      return newNotifications;
    });
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => {
      const newNotifications = prev.map(n =>
        n.id === id ? { ...n, read: true } : n
      );
      localStorage.setItem('opportunest_notifications', JSON.stringify(newNotifications));
      return newNotifications;
    });
  };

  // Get personalized opportunities based on user skills and roles
  const opportunities = user
    ? mockOpportunities.filter(opp => {
        const skillMatch = opp.requiredSkills.some(skill =>
          user.skills.some(userSkill =>
            userSkill.toLowerCase().includes(skill.toLowerCase()) ||
            skill.toLowerCase().includes(userSkill.toLowerCase())
          )
        );
        return skillMatch;
      })
    : mockOpportunities;

  // Get personalized courses based on user domain and roles
  const courses = user
    ? mockCourses.map(course => ({
        ...course,
        enrolled: learningProgress.some(p => p.courseId === course.id)
      }))
    : mockCourses;

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        opportunities,
        courses,
        savedOpportunities,
        toggleSaveOpportunity,
        learningProgress,
        updateLearningProgress,
        enrollInCourse,
        streak,
        updateStreak,
        notifications,
        markNotificationAsRead,
        addNotification
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};
