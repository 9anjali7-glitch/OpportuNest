import React from 'react';
import { useApp } from '../../../context/AppContext';

interface ProfileProps {
  onLogout: () => void;
}

export const Profile: React.FC<ProfileProps> = ({ onLogout }) => {
  const { user, streak } = useApp();

  if (!user) return null;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl mb-2">Profile</h2>
        <p className="text-gray-600">Manage your account</p>
      </div>

      {/* Profile Card */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-full flex items-center justify-center">
            <span className="text-white text-3xl">{user.name.charAt(0)}</span>
          </div>
          <div>
            <h3 className="text-xl">{user.name}</h3>
            <p className="text-gray-600">{user.email}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-600 mb-1">Degree</p>
            <p className="">{user.degree}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Year</p>
            <p className="">{user.year}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Domain</p>
            <p className="">{user.domain}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">City</p>
            <p className="">{user.city}</p>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t">
          <p className="text-sm text-gray-600 mb-2">Career Interests</p>
          <div className="flex flex-wrap gap-2">
            {user.roles.map(role => (
              <span key={role} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                {role}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-6 pt-6 border-t">
          <p className="text-sm text-gray-600 mb-2">Skills ({user.skills.length})</p>
          <div className="flex flex-wrap gap-2">
            {user.skills.map(skill => (
              <span key={skill} className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm">
                {skill}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-6 pt-6 border-t">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Learning Streak</p>
              <p className="text-2xl">🔥 {streak.currentStreak} Days</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Best Streak</p>
              <p className="text-2xl">🏆 {streak.longestStreak} Days</p>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="space-y-3">
        <button className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
          Edit Profile
        </button>
        <button className="w-full px-4 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition">
          Update Resume
        </button>
        <button
          onClick={onLogout}
          className="w-full px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
        >
          Logout
        </button>
      </div>
    </div>
  );
};
