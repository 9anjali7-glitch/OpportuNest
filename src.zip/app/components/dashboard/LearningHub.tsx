import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { Course } from '../../../lib/types';

export const LearningHub: React.FC = () => {
  const { courses, enrollInCourse, learningProgress, updateLearningProgress, streak } = useApp();
  const [filter, setFilter] = useState<string>('all');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  const filteredCourses = filter === 'all'
    ? courses
    : filter === 'enrolled'
    ? courses.filter(c => c.enrolled)
    : courses.filter(c => c.difficulty === filter);

  const getCourseProgress = (courseId: string) => {
    const progress = learningProgress.find(p => p.courseId === courseId);
    return progress?.progress || 0;
  };

  const handleStudy = (courseId: string) => {
    const currentProgress = getCourseProgress(courseId);
    const newProgress = Math.min(currentProgress + 10, 100);
    updateLearningProgress(courseId, newProgress);
  };

  return (
    <div className="space-y-6">
      {/* Header with Streak */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl mb-2">Learning Hub</h2>
          <p className="text-gray-600">Free courses from top providers</p>
        </div>
        <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-3 rounded-xl">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🔥</span>
            <div>
              <p className="text-2xl">{streak.currentStreak}</p>
              <p className="text-sm text-orange-100">Day Streak</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {[
          { value: 'all', label: 'All Courses' },
          { value: 'enrolled', label: 'My Courses' },
          { value: 'Beginner', label: 'Beginner' },
          { value: 'Intermediate', label: 'Intermediate' },
          { value: 'Advanced', label: 'Advanced' }
        ].map(option => (
          <button
            key={option.value}
            onClick={() => setFilter(option.value)}
            className={`px-4 py-2 rounded-lg transition whitespace-nowrap ${
              filter === option.value
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map(course => {
          const progress = getCourseProgress(course.id);

          return (
            <div key={course.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition">
              {/* Provider Badge */}
              <div className="flex items-center justify-between mb-3">
                <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
                  {course.provider}
                </span>
                {course.certification && (
                  <span className="text-xs text-green-600 flex items-center gap-1">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                      <path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm9.707 5.707a1 1 0 00-1.414-1.414L9 12.586l-1.293-1.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    Certificate
                  </span>
                )}
              </div>

              <h3 className="text-lg mb-2">{course.title}</h3>
              
              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-3">
                <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">
                  {course.difficulty}
                </span>
                <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">
                  ⏱️ {course.duration}
                </span>
              </div>

              <p className="text-gray-600 text-sm mb-4 line-clamp-2">{course.description}</p>

              {/* Skills */}
              <div className="flex flex-wrap gap-2 mb-4">
                {course.skills.slice(0, 3).map(skill => (
                  <span key={skill} className="px-2 py-1 bg-purple-50 text-purple-700 rounded text-xs">
                    {skill}
                  </span>
                ))}
              </div>

              {/* Progress or Enroll */}
              {course.enrolled ? (
                <div>
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-gray-600">Progress</span>
                    <span className="text-blue-600">{progress}%</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden mb-3">
                    <div
                      className="h-full bg-blue-600 transition-all"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <button
                    onClick={() => handleStudy(course.id)}
                    className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                  >
                    {progress === 100 ? 'Completed ✓' : 'Continue Learning'}
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    enrollInCourse(course.id);
                    setSelectedCourse(course);
                  }}
                  className="w-full px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition"
                >
                  Enroll Now
                </button>
              )}
            </div>
          );
        })}
      </div>

      {filteredCourses.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No courses found</p>
        </div>
      )}
    </div>
  );
};
