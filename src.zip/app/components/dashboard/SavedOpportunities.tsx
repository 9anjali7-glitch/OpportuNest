import React from 'react';
import { useApp } from '../../../context/AppContext';

export const SavedOpportunities: React.FC = () => {
  const { opportunities, savedOpportunities, toggleSaveOpportunity } = useApp();

  const saved = opportunities.filter(opp => savedOpportunities.includes(opp.id));

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl mb-2">Saved Opportunities</h2>
        <p className="text-gray-600">{saved.length} opportunities saved</p>
      </div>

      {saved.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {saved.map(opp => (
            <div key={opp.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg mb-1">{opp.title}</h3>
                  <p className="text-gray-600">{opp.company}</p>
                </div>
                <button
                  onClick={() => toggleSaveOpportunity(opp.id)}
                  className="p-2 hover:bg-gray-100 rounded-lg"
                >
                  <svg className="w-6 h-6 text-blue-600 fill-current" viewBox="0 0 24 24">
                    <path d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                  </svg>
                </button>
              </div>
              <p className="text-sm text-gray-600 mb-4">{opp.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Deadline: {new Date(opp.deadline).toLocaleDateString()}</span>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  Apply
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-white rounded-xl">
          <p className="text-gray-500">No saved opportunities yet</p>
        </div>
      )}
    </div>
  );
};
