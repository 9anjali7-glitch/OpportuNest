import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { Opportunity } from '../../../lib/types';

export const Opportunities: React.FC = () => {
  const { opportunities, user, savedOpportunities, toggleSaveOpportunity, addNotification } = useApp();
  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState('');

  const filteredOpportunities = opportunities.filter(opp => {
    const matchesFilter = filter === 'all' || opp.type === filter;
    const matchesSearch = opp.title.toLowerCase().includes(search.toLowerCase()) ||
                         opp.company.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getSkillMatchScore = (opp: Opportunity) => {
    if (!user) return 0;
    const matchingSkills = opp.requiredSkills.filter(skill =>
      user.skills.some(userSkill =>
        userSkill.toLowerCase().includes(skill.toLowerCase()) ||
        skill.toLowerCase().includes(userSkill.toLowerCase())
      )
    );
    return Math.round((matchingSkills.length / opp.requiredSkills.length) * 100);
  };

  const getMissingSkills = (opp: Opportunity) => {
    if (!user) return opp.requiredSkills;
    return opp.requiredSkills.filter(skill =>
      !user.skills.some(userSkill =>
        userSkill.toLowerCase().includes(skill.toLowerCase()) ||
        skill.toLowerCase().includes(userSkill.toLowerCase())
      )
    );
  };

  const typeColors: Record<string, { bg: string; text: string }> = {
    internship: { bg: 'bg-blue-100', text: 'text-blue-700' },
    job: { bg: 'bg-green-100', text: 'text-green-700' },
    hackathon: { bg: 'bg-purple-100', text: 'text-purple-700' },
    ideathon: { bg: 'bg-orange-100', text: 'text-orange-700' },
    competition: { bg: 'bg-red-100', text: 'text-red-700' }
  };

  const handleApply = (opp: Opportunity) => {
    addNotification({
      type: 'deadline',
      title: 'Application Started',
      message: `Don't forget to complete your application for ${opp.title} at ${opp.company}`,
      date: new Date().toISOString(),
      read: false
    });
    window.open(opp.applyUrl, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl mb-2">Explore Opportunities</h2>
        <p className="text-gray-600">Personalized opportunities based on your profile</p>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search opportunities..."
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <svg className="w-5 h-5 text-gray-400 absolute left-3 top-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>

        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="all">All Types</option>
          <option value="internship">Internships</option>
          <option value="job">Jobs</option>
          <option value="hackathon">Hackathons</option>
          <option value="ideathon">Ideathons</option>
          <option value="competition">Competitions</option>
        </select>
      </div>

      {/* Opportunities Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredOpportunities.map(opp => {
          const matchScore = getSkillMatchScore(opp);
          const missingSkills = getMissingSkills(opp);
          const isSaved = savedOpportunities.includes(opp.id);

          return (
            <div key={opp.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg mb-1">{opp.title}</h3>
                  <p className="text-gray-600">{opp.company}</p>
                </div>
                <button
                  onClick={() => toggleSaveOpportunity(opp.id)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  {isSaved ? (
                    <svg className="w-6 h-6 text-blue-600 fill-current" viewBox="0 0 24 24">
                      <path d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                    </svg>
                  ) : (
                    <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                    </svg>
                  )}
                </button>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                <span className={`px-3 py-1 rounded-full text-sm ${typeColors[opp.type].bg} ${typeColors[opp.type].text}`}>
                  {opp.type.charAt(0).toUpperCase() + opp.type.slice(1)}
                </span>
                <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                  📍 {opp.location}
                </span>
              </div>

              {/* Description */}
              <p className="text-gray-600 text-sm mb-4 line-clamp-2">{opp.description}</p>

              {/* Match Score */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">Skill Match</span>
                  <span className={`${matchScore >= 70 ? 'text-green-600' : matchScore >= 50 ? 'text-orange-600' : 'text-red-600'}`}>
                    {matchScore}%
                  </span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${matchScore >= 70 ? 'bg-green-500' : matchScore >= 50 ? 'bg-orange-500' : 'bg-red-500'}`}
                    style={{ width: `${matchScore}%` }}
                  />
                </div>
              </div>

              {/* Missing Skills */}
              {missingSkills.length > 0 && (
                <div className="mb-4">
                  <p className="text-sm text-gray-600 mb-2">Missing Skills:</p>
                  <div className="flex flex-wrap gap-2">
                    {missingSkills.slice(0, 3).map(skill => (
                      <span key={skill} className="px-2 py-1 bg-red-50 text-red-700 rounded text-xs">
                        {skill}
                      </span>
                    ))}
                    {missingSkills.length > 3 && (
                      <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
                        +{missingSkills.length - 3} more
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Footer */}
              <div className="flex items-center justify-between pt-4 border-t">
                <div className="text-sm">
                  <p className="text-gray-500">Deadline</p>
                  <p className="text-gray-900">{new Date(opp.deadline).toLocaleDateString()}</p>
                </div>
                <button
                  onClick={() => handleApply(opp)}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                >
                  Apply
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredOpportunities.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <p className="text-gray-500">No opportunities found</p>
        </div>
      )}
    </div>
  );
};
