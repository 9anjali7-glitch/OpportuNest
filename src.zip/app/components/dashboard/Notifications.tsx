import React from 'react';
import { useApp } from '../../../context/AppContext';

export const Notifications: React.FC = () => {
  const { notifications, markNotificationAsRead } = useApp();

  const unreadNotifications = notifications.filter(n => !n.read);
  const readNotifications = notifications.filter(n => n.read);

  const getIcon = (type: string) => {
    switch (type) {
      case 'opportunity':
        return '💼';
      case 'learning':
        return '📚';
      case 'deadline':
        return '⏰';
      case 'streak':
        return '🔥';
      default:
        return '🔔';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl mb-2">Notifications</h2>
        <p className="text-gray-600">{unreadNotifications.length} unread</p>
      </div>

      {unreadNotifications.length > 0 && (
        <div>
          <h3 className="text-lg mb-3">Unread</h3>
          <div className="space-y-3">
            {unreadNotifications.map(notification => (
              <div
                key={notification.id}
                className="bg-blue-50 border border-blue-200 rounded-xl p-4 hover:bg-blue-100 transition cursor-pointer"
                onClick={() => markNotificationAsRead(notification.id)}
              >
                <div className="flex gap-3">
                  <span className="text-2xl">{getIcon(notification.type)}</span>
                  <div className="flex-1">
                    <p className="">{notification.title}</p>
                    <p className="text-sm text-gray-600">{notification.message}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(notification.date).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {readNotifications.length > 0 && (
        <div>
          <h3 className="text-lg mb-3">Earlier</h3>
          <div className="space-y-3">
            {readNotifications.map(notification => (
              <div
                key={notification.id}
                className="bg-white border border-gray-200 rounded-xl p-4"
              >
                <div className="flex gap-3">
                  <span className="text-2xl opacity-50">{getIcon(notification.type)}</span>
                  <div className="flex-1">
                    <p className="text-gray-700">{notification.title}</p>
                    <p className="text-sm text-gray-500">{notification.message}</p>
                    <p className="text-xs text-gray-400 mt-1">
                      {new Date(notification.date).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {notifications.length === 0 && (
        <div className="text-center py-12 bg-white rounded-xl">
          <p className="text-gray-500">No notifications</p>
        </div>
      )}
    </div>
  );
};
