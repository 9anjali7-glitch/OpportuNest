import { Opportunity, Course } from './types';

export const mockOpportunities: Opportunity[] = [
  {
    id: '1',
    title: 'Software Engineering Intern',
    company: 'Google',
    type: 'internship',
    location: 'Bangalore, India',
    deadline: '2025-02-15',
    description: 'Join Google as a Software Engineering Intern and work on cutting-edge projects.',
    eligibility: ['Bachelor\'s or Master\'s in CS', '2025 or 2026 graduate'],
    requiredSkills: ['Python', 'Data Structures', 'Algorithms', 'System Design'],
    applyUrl: 'https://careers.google.com',
    postedDate: '2024-12-20'
  },
  {
    id: '2',
    title: 'AI/ML Hackathon 2025',
    company: 'Microsoft',
    type: 'hackathon',
    location: 'Virtual',
    deadline: '2025-01-30',
    description: 'Build innovative AI solutions and compete for prizes worth $50,000.',
    eligibility: ['Open to all students', 'Team of 2-4 members'],
    requiredSkills: ['Machine Learning', 'Python', 'TensorFlow'],
    applyUrl: 'https://microsoft.com/hackathon',
    postedDate: '2024-12-22'
  },
  {
    id: '3',
    title: 'Product Manager Intern',
    company: 'Amazon',
    type: 'internship',
    location: 'Hyderabad, India',
    deadline: '2025-02-28',
    description: 'Work with cross-functional teams to deliver innovative products.',
    eligibility: ['MBA or Final year engineering', 'Strong analytical skills'],
    requiredSkills: ['Product Management', 'Data Analysis', 'Communication'],
    applyUrl: 'https://amazon.jobs',
    postedDate: '2024-12-23'
  },
  {
    id: '4',
    title: 'Full Stack Developer',
    company: 'Flipkart',
    type: 'job',
    location: 'Bangalore, India',
    deadline: '2025-01-31',
    description: 'Build scalable web applications using modern tech stack.',
    eligibility: ['B.Tech/MCA with 0-2 years exp', 'Strong coding skills'],
    requiredSkills: ['React', 'Node.js', 'MongoDB', 'JavaScript'],
    applyUrl: 'https://flipkart.com/careers',
    postedDate: '2024-12-25'
  },
  {
    id: '5',
    title: 'Smart India Hackathon 2025',
    company: 'Government of India',
    type: 'hackathon',
    location: 'Multiple Cities',
    deadline: '2025-02-10',
    description: 'Solve real-world problems for government ministries.',
    eligibility: ['Students from recognized institutions', 'Team of 6 members'],
    requiredSkills: ['Problem Solving', 'Web Development', 'Mobile Apps'],
    applyUrl: 'https://sih.gov.in',
    postedDate: '2024-12-18'
  },
  {
    id: '6',
    title: 'Data Science Competition',
    company: 'Kaggle',
    type: 'competition',
    location: 'Online',
    deadline: '2025-03-15',
    description: 'Predict customer churn using ML models. Prize: $10,000',
    eligibility: ['Open to all'],
    requiredSkills: ['Python', 'Machine Learning', 'Data Analysis', 'Pandas'],
    applyUrl: 'https://kaggle.com/competitions',
    postedDate: '2024-12-26'
  },
  {
    id: '7',
    title: 'Cloud Engineering Intern',
    company: 'IBM',
    type: 'internship',
    location: 'Pune, India',
    deadline: '2025-02-20',
    description: 'Work on cloud infrastructure and DevOps solutions.',
    eligibility: ['B.Tech/MCA students', '2025/2026 graduates'],
    requiredSkills: ['AWS', 'Docker', 'Kubernetes', 'Linux'],
    applyUrl: 'https://ibm.com/careers',
    postedDate: '2024-12-24'
  },
  {
    id: '8',
    title: 'UI/UX Design Challenge',
    company: 'Adobe',
    type: 'competition',
    location: 'Virtual',
    deadline: '2025-01-25',
    description: 'Design innovative user experiences for mobile apps.',
    eligibility: ['Design students', 'Portfolio required'],
    requiredSkills: ['Figma', 'UI Design', 'User Research', 'Prototyping'],
    applyUrl: 'https://adobe.com/design-challenge',
    postedDate: '2024-12-21'
  }
];

export const mockCourses: Course[] = [
  {
    id: '1',
    title: 'Python for Everybody',
    provider: 'Microsoft Learn',
    domain: 'Programming',
    difficulty: 'Beginner',
    duration: '40 hours',
    certification: true,
    description: 'Learn Python programming from scratch with hands-on projects.',
    skills: ['Python', 'Programming Basics', 'Data Structures'],
    url: 'https://microsoft.com/learn/python'
  },
  {
    id: '2',
    title: 'Machine Learning Specialization',
    provider: 'Google AI',
    domain: 'AI/ML',
    difficulty: 'Intermediate',
    duration: '60 hours',
    certification: true,
    description: 'Master machine learning algorithms and deep learning basics.',
    skills: ['Machine Learning', 'TensorFlow', 'Neural Networks'],
    url: 'https://google.com/ai-courses'
  },
  {
    id: '3',
    title: 'AWS Cloud Practitioner',
    provider: 'AWS Training',
    domain: 'Cloud Computing',
    difficulty: 'Beginner',
    duration: '30 hours',
    certification: true,
    description: 'Get certified in AWS cloud fundamentals.',
    skills: ['AWS', 'Cloud Computing', 'DevOps'],
    url: 'https://aws.amazon.com/training'
  },
  {
    id: '4',
    title: 'Full Stack Web Development',
    provider: 'Microsoft Learn',
    domain: 'Web Development',
    difficulty: 'Intermediate',
    duration: '80 hours',
    certification: true,
    description: 'Build modern web applications with React and Node.js.',
    skills: ['React', 'Node.js', 'MongoDB', 'JavaScript'],
    url: 'https://microsoft.com/learn/fullstack'
  },
  {
    id: '5',
    title: 'Data Analytics with Python',
    provider: 'IBM Skills',
    domain: 'Data Science',
    difficulty: 'Intermediate',
    duration: '50 hours',
    certification: true,
    description: 'Analyze data and create visualizations using Python.',
    skills: ['Python', 'Pandas', 'Data Visualization', 'NumPy'],
    url: 'https://ibm.com/training/data-analytics'
  },
  {
    id: '6',
    title: 'Cybersecurity Fundamentals',
    provider: 'TCS iON',
    domain: 'Cybersecurity',
    difficulty: 'Beginner',
    duration: '25 hours',
    certification: true,
    description: 'Learn the basics of cybersecurity and ethical hacking.',
    skills: ['Security', 'Network Security', 'Ethical Hacking'],
    url: 'https://tcsion.com/cybersecurity'
  },
  {
    id: '7',
    title: 'UI/UX Design Bootcamp',
    provider: 'Google Design',
    domain: 'Design',
    difficulty: 'Beginner',
    duration: '35 hours',
    certification: true,
    description: 'Create stunning user interfaces and experiences.',
    skills: ['Figma', 'UI Design', 'User Research', 'Prototyping'],
    url: 'https://google.com/design/courses'
  },
  {
    id: '8',
    title: 'Blockchain Development',
    provider: 'IBM Blockchain',
    domain: 'Blockchain',
    difficulty: 'Advanced',
    duration: '70 hours',
    certification: true,
    description: 'Build decentralized applications on blockchain.',
    skills: ['Blockchain', 'Smart Contracts', 'Solidity', 'Web3'],
    url: 'https://ibm.com/blockchain/training'
  }
];

export const domains = [
  'Computer Science',
  'Information Technology',
  'Electronics & Communication',
  'Mechanical Engineering',
  'Civil Engineering',
  'Business Administration',
  'Data Science',
  'Design',
  'Other'
];

export const careerRoles = [
  'Software Engineer',
  'Data Scientist',
  'Product Manager',
  'UI/UX Designer',
  'Full Stack Developer',
  'DevOps Engineer',
  'Business Analyst',
  'Cloud Architect',
  'Machine Learning Engineer',
  'Cybersecurity Analyst'
];

export const cities = [
  'Bangalore',
  'Mumbai',
  'Delhi',
  'Hyderabad',
  'Pune',
  'Chennai',
  'Kolkata',
  'Ahmedabad',
  'Gurgaon',
  'Noida'
];

export const commonSkills = [
  'Python',
  'JavaScript',
  'React',
  'Node.js',
  'Java',
  'C++',
  'SQL',
  'MongoDB',
  'AWS',
  'Docker',
  'Machine Learning',
  'Data Analysis',
  'Communication',
  'Problem Solving',
  'Leadership'
];
