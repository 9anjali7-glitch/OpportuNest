export interface User {
  id: string;
  email: string;
  name: string;
  degree: string;
  year: string;
  domain: string;
  city: string;
  roles: string[];
  skills: string[];
  resumeUploaded: boolean;
}

export interface Opportunity {
  id: string;
  title: string;
  company: string;
  type: 'internship' | 'job' | 'hackathon' | 'ideathon' | 'competition';
  location: string;
  deadline: string;
  description: string;
  eligibility: string[];
  requiredSkills: string[];
  applyUrl: string;
  postedDate: string;
}

export interface Course {
  id: string;
  title: string;
  provider: string;
  domain: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  certification: boolean;
  description: string;
  skills: string[];
  url: string;
  enrolled?: boolean;
}

export interface LearningProgress {
  courseId: string;
  progress: number;
  lastStudied: string;
  completed: boolean;
}

export interface Streak {
  currentStreak: number;
  longestStreak: number;
  lastStudyDate: string;
}

export interface Notification {
  id: string;
  type: 'opportunity' | 'learning' | 'deadline' | 'streak';
  title: string;
  message: string;
  date: string;
  read: boolean;
}
